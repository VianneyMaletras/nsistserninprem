import csv


def charger_donnees(nom_fichier: str) -> list:
    """
    charge le fichier csv spécifié et retourne un tableau de dictionnaires
    les données autre que le label seront considérées comme des nombres flottants

    Paramètres:
        nom_fichier (str): nom du fichier csv à charger

    Renvoie:
        list: le tableau des dictionnaires contenant les données du fichier
    """
    ...


def dist_euclidienne(entrainement: dict, test: dict) -> float:
    """
    calcule la distance euclidienne entre deux données

    Paramètres:
        entrainement (dict): une entité d'entrainement
        test (dict): une entité de test

    Renvoie:
        float: la distance euclidienne entre les deux données
    """
    d = 0
    for cle, val in test.items():
        if cle != "label":
            d = d + (test[cle] - entrainement[cle]) ** 2
    return d

def dist_manhattan(entrainement: dict, test: dict) -> float:
    """
    calcule la distance de Manhattan entre deux données

    Paramètres:
        entrainement (dict): une entité d'entrainement
        test (dict): une entité de test

    Renvoie:
        float: la distance de Manhattan entre les deux données
    """
    d = 0
    for cle, val in test.items():
        if cle != "label":
            d = d + abs(test[cle] - entrainement[cle])
    return d


def calculer_distances(tab_entrainement: list, test: dict) -> list:
    """
    calcule toutes les distances entre une entité de test et toutes les entités d'entrainement

    Paramètres:
        tab_entrainement (list): tableau des dictionnaires des entités d'entrainement
        test (dict): entité de test

    Renvoie:
        list: tableau des distances entre l'entité de test et toutes les entités d'entrainement; le tableau contiendra des tuples (label, distance)
    """
    distances = []
    for ligne in tab_entrainement:
        d = ...
        distances.append(...)

    return distances


def trier(distances: list) -> None:
    """
    trie en place les distances par ordre croissant avec un tri par insertion
    le tableau contient des tuples (label, distance) et le tri sera effectué en fonction de la distance

    Paramètres:
        distances (list): le tableau à trier
    """
    ...


def rechercher_maxi(voisins: dict) -> str:
    """
    recherche la valeur la plus grande dans un dictionnaire

    Paramètres:
        voisins (dict): le dictionnaire à parcourir

    Renvoie:
        str: la clé de la valeur la plus grande
    """
    ...


def trouver_k_majoritaire(k: int, distances: list) -> str:
    """
    trouve le label majoritaire parmi les k plus proches voisins

    Paramètres:
        k (int): valeur de k
        distances (list): tableau des distances

    Renvoie:
        str: label majoritaire
    """
    compteur_voisins = {}
    for i in range(k):
        label = distances[i][0]
        if label in compteur_voisins:
            compteur_voisins[...] += 1
        else:
            compteur_voisins[label] = ...
    
    return rechercher_maxi(...)


# Programme principal
# Initialisation
k = 3
tab_entrainement = charger_donnees("iris-entrainement.csv")
tab_test = charger_donnees("iris-test.csv")
reussi = 0

# Phase d'entrainement
for test in tab_test:
    distances = calculer_distances(tab_entrainement, test)
    trier(distances)
    label = trouver_k_majoritaire(k, distances)
    if label == test["label"]:
        reussi = reussi + 1

# Efficacité
print(reussi / len(tab_test) * 100, "% de réussite")
