#!/usr/bin/env python3
# -*- coding: utf-8 -*-


from constantes import *


def verif_gagnant(grille: list, joueur: int, ligne: int, colonne: int) -> bool:
    """
    Vérifie si la position est gagnante

    Args:
        grille (list): le jeu
        joueur (int): la couleur du joueur
        ligne (int): ligne du dernier jeton
        colonne (int): colonne du dernier jeton

    Returns:
        bool: True si la position est gagnante
    """    
    pass


def verif_verticale(grille: list, joueur: int, ligne: int, colonne: int) -> bool:
    """
    vérifie si l'alignement vertical est gagnant

    Args:
        grille (list): le jeu
        joueur (int): la couleur en cours
        ligne (int): la ligne du dernier jeton placé
        colonne (int): la colonne du dernier jeton placé

    Returns:
        bool: True si gagnant
    """
    compteur = 0
    pass


def verif_horizontale_droite(grille: list, joueur: int, ligne: int, colonne: int) -> bool:
    """
    vérifie si l'alignement horizontal vers la droite est gagnant

    Args:
        grille (list): le jeu
        joueur (int): la couleur en cours
        ligne (int): la ligne du dernier jeton placé
        colonne (int): la colonne du dernier jeton placé

    Returns:
        bool: True si gagnant
    """
    compteur = 0
    pass


def verif_horizontale_gauche(grille: list, joueur: int, ligne: int, colonne: int) -> bool:
    """
    vérifie si l'alignement horizontal vers la gauche est gagnant

    Args:
        grille (list): le jeu
        joueur (int): la couleur en cours
        ligne (int): la ligne du dernier jeton placé
        colonne (int): la colonne du dernier jeton placé

    Returns:
        bool: True si gagnant
    """
    compteur = 0
    pass
