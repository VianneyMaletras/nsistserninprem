def afficher_allumettes(nb:int)->str:
    return '|'*nb
    
def afficher_choix():
    pass
def afficher_gagnant():
    pass
