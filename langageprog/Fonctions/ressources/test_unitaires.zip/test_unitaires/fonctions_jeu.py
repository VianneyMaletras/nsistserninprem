def choisir_depart():
    pass